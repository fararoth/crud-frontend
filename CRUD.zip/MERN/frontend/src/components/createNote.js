import React, { Component } from "react";

export default class createNote extends Component {
  render() {
    return (
      <div>
        <h1>CREATE NOTE</h1>
      </div>
    );
  }
}
