import React, { Component } from "react";

export default class NoteList extends Component {
  render() {
    return <div>NOTHING HERE YET</div>;
  }
}
